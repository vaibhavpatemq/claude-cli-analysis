Synthetic sample ~/.claude folder for testing analytics tools. All data is fake.
Copy .claude to your home dir (or point your app at it).
