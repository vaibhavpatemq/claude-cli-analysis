# sample shell snapshot
export PATH=$PATH
