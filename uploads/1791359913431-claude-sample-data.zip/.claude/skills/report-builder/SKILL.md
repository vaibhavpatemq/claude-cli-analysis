---
name: report-builder
description: Build markdown analysis reports
---

# report-builder

Steps:
1. Inspect input
2. Run analysis
3. Write summary
