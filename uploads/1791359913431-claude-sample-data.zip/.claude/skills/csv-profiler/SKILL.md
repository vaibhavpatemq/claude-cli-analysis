---
name: csv-profiler
description: Profile CSV files: types, nulls, distributions
---

# csv-profiler

Steps:
1. Inspect input
2. Run analysis
3. Write summary
