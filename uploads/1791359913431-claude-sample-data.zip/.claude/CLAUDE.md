# Global preferences
- Prefer TypeScript and Python 3.11
- Write tests for new functions
- Keep answers concise
