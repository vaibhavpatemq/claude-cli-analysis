---
description: Fix GitHub issue #$ARGUMENTS following o
argument-hint: [args]
---

Fix GitHub issue #$ARGUMENTS following our code style.
