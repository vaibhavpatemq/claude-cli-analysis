---
description: Generate a changelog from recent git com
argument-hint: [args]
---

Generate a changelog from recent git commits.
