---
description: Profile the dataset at $ARGUMENTS and su
argument-hint: [args]
---

Profile the dataset at $ARGUMENTS and summarize key stats.
