---
description: Review the staged changes: $ARGUMENTS
argument-hint: [args]
---

Review the staged changes: $ARGUMENTS
